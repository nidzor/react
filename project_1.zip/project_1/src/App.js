import logo from './logo.svg';
import './App.css';
import Note from './components/Note/note';
import NoteList from './components/NoteList/noteList';


function App() {
  return (
    <>
      <p>e</p>
      <NoteList/>
    </>
  );
}

export default App;
