export const NOTES = [
    {
        id:1,
        title: "Title 1",
        description: "desc 1"
    },
    {
        id:1,
        title: "Title 2",
        description: "desc 2"
    },
    {
        id:1,
        title: "Title 3",
        description: "desc 3"
    },
    {
        id:1,
        title: "Title 4",
        description: "desc 4"
    }
]