import Note from "../Note/note";
import { NOTES } from "./data";

const NoteList = () => {
    
    return(
        <div>
            {NOTES.map(
                (currentNote) => (
                    <Note key = {currentNote.key} 
                    title={currentNote.title} 
                    description={currentNote.description} ></Note>
                )
            )}
        </div>
    )
}
export default NoteList