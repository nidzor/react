const Modal = ({active, setIsModal}) => {
    return active && ( <>
    <form>
        <label> Title </label>
        <input></input>
        <label> Description </label>
        <input>  </input>

        <button>
            type = button
            onClick = {setIsModal => false}
        </button>
    </form>
    </>)
}

export default Modal