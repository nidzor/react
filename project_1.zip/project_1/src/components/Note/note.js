import {useState} from "react";
import './style.css'
// import style from './style.modules.css'
import Modal from "../Modal/modal";


const Note = ({title , description}) => {
    const [showDescription , setShowDescription] = useState(false)
    const [isModal, setIsModal] = useState(false)

    return(
        <>
            {/* <button onClick={() => setShowDescription(!showDescription)}> */}


            <button
            className="This_"
            onClick={() => setShowDescription(
                prevState => !prevState
            )}>
                <h2>{title}</h2>
            </button>
            
            {showDescription && (
                <>
                    <h3>{description}</h3>
                    <img src="RDT_20240916_1632524997761592346761661.jpg"></img>
                </>
            )}

            <Modal active={isModal} setIsModal={setIsModal}/>
            {/* <Modal active={isModal} {...{setIsModal}}/> */}
        </>
    )
}
export default Note


// const NoteList = ({}) => {
//     <>
//         Note()
//     </>
// }